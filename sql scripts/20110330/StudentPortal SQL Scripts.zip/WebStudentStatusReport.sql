USE [MIL-FRE]
GO

/****** Object:  Table [dbo].[WebStudentStatusReport]    Script Date: 03/30/2011 16:11:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[WebStudentStatusReport](
	[ID] [int] NOT NULL,
	[SSReport] [bit] NOT NULL
) ON [PRIMARY]

GO

